<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('course_teachers', function (Blueprint $table) {
            $table->id();
                
            // llaves fonraneas de courses y teachers
            $table->unsignedBigInteger('course_id');
            $table->unsignedBigInteger('teacher_id');

            // Referencia courses
            $table->foreign('course_id')
                ->references('id')
                ->on('courses')->onDelete('cascade');

            // Referencia teachers
            $table->foreign('teacher_id')
                ->references('id')
                ->on('teachers')->onDelete('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('course_teachers');
    }
};
